# Mithril Workspace

Canonical portable workspace protocol, sync client and React renderer shared by Mithril Web and Desktop. Source lives in `mithril-lang/mithril-fund/packages/workspace`; Desktop consumes the compiled npm pack artifact rather than maintaining a second UI source.

Enable sync explicitly for this account. Only user-authored display profile, locale/theme/model preferences, projects, Kanban tasks, memory notes, capability preferences and Office workrooms are synchronized. This package cannot inspect local files, runtime configuration, credentials or device permissions.

Discover reads the official Mithril Registry through a platform adapter. Plugin installation, local memory providers, 3D/native Office runtime controls and device grants remain in their native flows. Cloud capability preferences do not grant permissions. Existing native Desktop data is not imported, overwritten or removed.

Records use owner authorization, schema version1, compare-and-swap revisions, operation IDs, tombstones and paginated history. Offline changes remain in this window's in-memory outbox and retry with the same operation ID. Closing the window discards unsent changes after the browser's pending-change warning. Account changes clear the workspace instance. The initial service limit is1000 records including tombstones.

Browser uses HttpOnly session cookies and existing origin/CSRF checks. Desktop uses its existing secure token store only in the main process and requires explicitly issued workspace:read/write scopes; this package never receives the bearer. No token upgrade or grant occurs automatically.

Build `npm run build -w @mithril/workspace`, then `npm pack -w @mithril/workspace`. The tarball contains compiled ESM, declarations and CSS, with no Electron IPC or local filesystem imports.
