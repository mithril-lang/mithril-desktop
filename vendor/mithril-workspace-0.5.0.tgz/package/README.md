# Mithril shared workspace 0.5

Discover, Office and Kanban use the same compiled React renderer in Desktop and Web. Signed-in clients automatically read canonical api.mithril.fund workspace records. Web uses its same-origin authenticated facade; it owns no separate workspace database. Desktop uses trusted IPC and its secure-store token against the fixed API origin.

D1 workspace_records, workspace_history and workspace_operations own portable metadata with user isolation, revisions, tombstones, history and operation replay protection. Object storage must also be mediated by api.mithril.fund; this change does not upload local project files or introduce direct client D1/R2 access.

The release-pinned public Discover catalog includes the same Mithril and Hermes sources as Desktop. Adding a capability saves intent only; installation and device grants remain reviewed native operations. Office cloud profiles do not prove live runtime presence. Kanban supports the Desktop lanes, task descriptions, assignees, priorities and project boards; moving a task never dispatches code.

Clients observe every five seconds and on focus. Identity changes clear prior-owner cache and pending edits. Save/retry writes explicitly; observation never replays tools. Unsent edits currently survive only in the window and are lost on close; before-unload warns while pending. No durable offline outbox is claimed.

Native records remain unchanged. Reviewed selected imports preserve portable task fields, current-board relationships, bot instructions and project metadata; credentials, absolute paths, device permission grants and native run histories are excluded. Import is never automatic.

Package 0.5.0 is required by both clients for rich task fields. Older clients fail closed on unsupported data rather than truncating it. Build with npm run build -w @mithril/workspace and pack the compiled ESM, declarations, CSS and scene assets. Existing session transport, Kuro browser execution and authorization boundaries remain unchanged.
